package com.springcore.lifecycle;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Pepsi implements InitializingBean,DisposableBean{
	private double price;

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Pepsi() {
		super();
	}

	@Override
	public String toString() {
		return "Pepsi [price=" + price + "]";
	}
	//init method bas naam change ho gaya hai 
	public void afterPropertiesSet() throws Exception {
		System.out.println("taking pepsi: init");
	}
	//ye to naam se hi smjh raha hai destroy krne ka kaam krega
	public void destroy() throws Exception{
		System.out.println("going to keep the bottle at shop after drinking");
	}
	
}
