package com.springcore.core;
	
public class Student {
	private int id;
	private String add;
	private String name;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Student() {
		super();
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", add=" + add + ", name=" + name + "]";
	}
	public Student(int id, String add, String name) {
		super();
		this.id = id;
		this.add = add;
		this.name = name;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}
	
	
}
