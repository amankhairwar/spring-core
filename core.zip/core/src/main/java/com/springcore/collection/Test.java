package com.springcore.collection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("com/springcore/collection/collectionconfig.xml");
		Student d1=(Student)context.getBean("data");
		System.out.println(d1.getPhones());
		System.out.println(d1.getAddresses());
		System.out.println(d1.getCourses());
	}

}
