package com.springcore.collection;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Student {
	private int id;
	private List<String> phones;
	private Set<String> addresses;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public List<String> getPhones() {
		return phones;
	}
	public void setPhones(List<String> phones) {
		this.phones = phones;
	}
	public Set<String> getAddresses() {
		return addresses;
	}
	public Student(int id, List<String> phones, Set<String> addresses, Map<String, String> courses) {
		super();
		this.id = id;
		this.phones = phones;
		this.addresses = addresses;
		this.courses = courses;
	}
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", phones=" + phones + ", addresses=" + addresses + ", courses=" + courses + "]";
	}
	public void setAddresses(Set<String> addresses) {
		this.addresses = addresses;
	}
	public Map<String, String> getCourses() {
		return courses;
	}
	public void setCourses(Map<String, String> courses) {
		this.courses = courses;
	}
	private Map<String, String> courses;
	
}
